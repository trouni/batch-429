class SuperClass
end

class SubClass < SuperClass # ParentClass
end

class SubSubClass < SubClass
end