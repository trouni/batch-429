class Chef
  attr_reader :name, :restaurant

  def initialize(name, restaurant)
    @name = name
    @restaurant = restaurant
  end
end